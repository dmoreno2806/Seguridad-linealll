 
<div class="jumbotron">
    <h1 class="display-3">Proyecto Final</h1>
    <p class="lead">Linea de profundización 3</p>
    <hr class="my-2">
    <p>Julián Vásquez Corredor</p>
    <p>Eva Paola Joya</p>
    <p>Diego Alejandro Moreno</p>
</div>