
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="error-template">
                    <h1>
                        Oops!</h1>
                    <h2 class="mt-3 mb-3">
                        404 Not Found</h2>
                    <div class="error-details">
                        La ruta a la que intenta acceder no existe
                    </div>
                    <div class="error-actions">
                        <a href="?controller=paginas&action=inicio" class="btn btn-primary btn-lg mt-3"><span class="glyphicon glyphicon-home"></span>
                            Regresar 
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
