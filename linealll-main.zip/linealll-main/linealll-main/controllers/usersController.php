<?php 
	require_once('../models/usuarios.php');

	$obUser= new UsuarioModel();

	if(isset($_REQUEST["validar"])){

		$r=$obUser->validarUsuario($_REQUEST["login"],$_REQUEST["password"]);
		if ($r==1) {
			session_start();
			$_SESSION["s1"]=$_REQUEST["login"];
			header("Location:../index.php");
		}
		else

			echo"<script>alert('Usuario o clave no validos')</script>";
	}

	require '../views/login.php';


 ?>