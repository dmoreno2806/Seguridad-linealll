<?php

 session_start();

            if (isset($_REQUEST["c"])) {
                session_destroy();
                header("Location:/linealll-main/linealll-main/controllers/usersController.php");
            }

            if (isset($_SESSION["s1"])) {
                echo "Bienvedid@".$_SESSION["s1"];
                echo "<a href='http://serviciosot.com/linealll-main/linealll-main/index.php?c=1'> Cerrar sesion</a>";

                
            }
            else
                header("Location:/linealll-main/linealll-main/controllers/usersController.php");
            
    require_once('models/curso.php');
    require_once('conexion.php');
    BD::createInstance();

    class CursosController {
        public function index()
        {
            $cursos = Curso::getAll();
            include_once('views/cursos/index.php');
        }
        public function store()
        {
            if ($_POST) {
                $nombre = $_POST['nombre'];
                $codigo = $_POST['codigo'];
                $creditos = $_POST['creditos'];
                Curso::create($nombre, $codigo, $creditos);
                header("Location:./?controller=cursos&action=index");
            }
            else{
                include_once('views/cursos/store.php');
            }
        }
        public function update()
        {
            $id = $_GET['id'];
            $curso = Curso::get($id);

            if ($_POST) {
                $id = $curso->id;
                $nombre = $_POST['nombre'];
                $codigo = $_POST['codigo'];
                $creditos = $_POST['creditos'];
                Curso::update($id, $nombre, $codigo, $creditos);
                header("Location:./?controller=cursos&action=index");
            }

            include_once('views/cursos/update.php');
        }
        public function delete()
        {
            $id = $_GET['id'];
            Curso::delete($id);
            header("Location:./?controller=cursos&action=index");
        }
    }
?>