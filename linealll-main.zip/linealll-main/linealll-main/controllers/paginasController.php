<?php

	
    class PaginasController {
        public function inicio() {

        	 session_start();

            if (isset($_REQUEST["c"])) {
                session_destroy();
                header("Location:/linealll-main/linealll-main/controllers/usersController.php");
            }

            if (isset($_SESSION["s1"])) {
                echo "Bienvedid@".$_SESSION["s1"];
                 include_once('views/paginas/inicio.php');
                echo "<a href='http://serviciosot.com/linealll-main/linealll-main/index.php?c=1'> Cerrar sesion</a>";

                
            }
            else
                header("Location:/linealll-main/linealll-main/controllers/usersController.php");
        
           
        }

        public function error() {
            include_once('views/paginas/error.php');
        }
    }
?>