<?php

	define("SERVER", "dblinea.cutiqdwfh31b.us-east-2.rds.amazonaws.com");
	define("USER", "admin");
	define("PASSWORD", "dblinea2021");
	define("BASE", "db_linea");
	define("CHAR", "utf-8");


?>