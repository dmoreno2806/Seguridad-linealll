<?php 
    $conexion = new mysqli('dblinea.cutiqdwfh31b.us-east-2.rds.amazonaws.com','admin','dblinea2021','db_linea');
    if($conexion-> connect_error){
        die('No se pudo conectar al servidor');
    }

?>